IFFT Hann analysis
Parameter:
start_hz = 9000.0
target_stop_hz = 191977000.0  (approx 192 MHz)
target_points = 6000
step_hz = 32000.0
window = hann
epsilon_r = 2.23
Dmax = 3136.811 m
distance_sample = 0.261423 m
Procedure follows the uploaded GUI logic: skip first data point, frequency filtering/interpolation to linear grid, DC extrapolation, conjugate spectrum, Hann window on full double-sided spectrum, causal IFFT, distance conversion.
