本目录为 6250点、32kHz、约200MHz、Hann窗 的 IFFT 现场数据分析结果。

文件说明：
- summary_6250_200M_32k_hann.csv：逐案例主指标汇总
- top_peaks_6250_200M_32k_hann.csv：各案例绝对幅值前若干峰
- *_full.png：每个案例的 impulse real + step response 全距离图
- *_candidate_zoom.png：每个案例候选远端附近放大图
- 完整分析报告_6250点_32kHz_200MHz_Hann.md：完整文字分析报告

参数：
start_hz=9kHz
step_hz=32kHz
positive_points=6250
effective_stop≈199.977MHz
grid_max≈199.968MHz
epsilon_r=2.25
Dmax≈3122.838m
