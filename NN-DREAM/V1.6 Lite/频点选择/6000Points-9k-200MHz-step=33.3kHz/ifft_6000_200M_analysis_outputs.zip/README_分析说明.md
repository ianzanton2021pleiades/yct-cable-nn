# IFFT 现场数据分析：9 kHz ~ 200 MHz，6000 点

参数：
- start_hz = 9 kHz
- stop_hz = 200 MHz
- points = 6000
- 实际 step_hz = 33.337390 kHz
- 程序默认 epsr = 2.23 时显示距离窗口 Dmax = 3010.97 m
- 距离采样间隔约 0.251 m

说明：
- 每个 <=2.5 km 文件夹选取一个 A 相 CSV。
- 按原 IFFT 程序的主要数理流程：读取 CSV、跳过第一个数据点、插值到线性频率网格、构造共轭双边频谱、估计 DC、IFFT、归一化 impulse/step。
- 图片中的距离为程序按 epsr=2.23 换算的显示距离，不等于必然准确的物理长度。
- causal IFFT 的周期末端接近 Dmax 处容易出现近端负时间/周期连接伪影；越接近 Dmax 的远端反射，风险越高。
