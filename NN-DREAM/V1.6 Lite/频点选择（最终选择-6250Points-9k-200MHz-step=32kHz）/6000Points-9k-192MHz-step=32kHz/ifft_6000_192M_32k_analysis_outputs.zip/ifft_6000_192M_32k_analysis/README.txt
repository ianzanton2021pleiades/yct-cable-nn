IFFT analysis for <=2.5km cases
Parameters:
  start_hz = 9000.0
  step_hz = 32000.0
  points = 6000
  exact stop_hz = 191977000.0 Hz = 191.977000 MHz
  eps_r = 2.23
  Dmax_theory = 3136.811 m
Pipeline: skip first valid point; interpolate S11 real/imag to linear grid; build conjugate spectrum; estimate DC; rectangular window; causal IFFT; distance = v*t/2.
