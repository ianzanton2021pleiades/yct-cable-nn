纯算法末端识别结果包

参数：
- 6250 points
- step_hz = 32 kHz
- effective stop_hz = 199.977 MHz
- window = Hann
- epsilon_r = 2.25

关键文件：
- pure_algorithm_endpoint_summary.csv：纯算法末端估计汇总
- pure_algorithm_event_candidates.csv：每个样品的局部事件候选及分数
- plots/*.png：红色虚线为纯算法 candidate，不使用文件夹长度先验
- 完整报告_纯算法末端识别_6250点_32kHz_200MHz_Hann.md：完整文字分析报告
