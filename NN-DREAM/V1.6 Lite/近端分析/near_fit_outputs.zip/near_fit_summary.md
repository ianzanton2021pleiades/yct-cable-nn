# Near 模块拟合结果摘要

目标数据：开路 0degree、短路平行、双端平行 S21。频段：0.1–200 MHz。

结论：纯 RLC-only Near 不能贴合引线实验结果；加入约 22.5 ns 单向延迟后，RLC 残差主值稳定在 R≈2–8 Ω、L≈0.38–0.42 µH、C≈4.8–5.1 pF。

推荐用于 YAML 的主 case：near_lab_balanced。
