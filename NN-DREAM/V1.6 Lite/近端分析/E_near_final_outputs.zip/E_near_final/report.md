# E 测试鳄鱼夹 near-end 标定拟合报告

目标数据：开路 0degree、短路 II-ShortEnd、双端 II 两次测量的复数平均。拟合时剔除异常的 9 kHz 首点，主拟合频段为 100 kHz–200 MHz。

## 关键结论

- 纯三参数 RLC 不能同时拟合开路、短路和双端数据。短路输入阻抗在约 54.3 MHz 出现强峰，开路输入阻抗在约 102.2 MHz 出现低阻抗点，这已经是分布式/谐振行为。
- 对 V1.6-Lite 的 9 kHz–200 MHz 阶段，若必须保持 Idea 中的 R_N/L_N/C_N 三参数 near 模块，推荐只把它作为保守低维扰动主值，而不是希望它复现夹具全频 S 参数。
- 若允许 near 模型扩展到 4–5 个参数，损耗传输线模型明显比 RLC 更接近：Case6 使用 Zc, tau, alpha0, alpha1 四参数；Case7 使用 Zc, tau, alpha0, alpha1, C 五参数。

## 推荐参数

### 三参数 RLC 保守主值

R_N_cal = 20.0 ohm; L_N_cal = 213.6 nH; C_N_cal = 21.84 pF. 这是三参数同时拟合的折中值，但误差较大。

### 五参数更优模型：损耗传输线 + 端部并联 C

Case7: Zc = 204.1 ohm; tau = 2.618 ns; alpha0 = 1.19e-4; alpha1 = 1.502; C = 15.33 pF. 该模型对双端 S21 幅值拟合最好，但开路反射拟合牺牲较大。

### 四参数综合模型：损耗传输线

Case6: Zc = 252.8 ohm; tau = 2.610 ns; alpha0 = 1.155e-3; alpha1 = 0.3445. 该模型在开路、短路、双端 S11/S21 的综合复数误差上最好。

详细数值见 fit_summary_combined.csv。

### 低频 100k–10MHz one-port RLC 主值

R_N_cal = 0.218 ohm; L_N_cal = 731.97 nH; C_N_cal = 21.57 pF. 该组只用于低频开路/短路主值，不能代表 20–200 MHz。
